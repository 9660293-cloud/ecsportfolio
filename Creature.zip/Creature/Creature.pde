// Ole Leimbach | Feb 24 2026 | Creature
void setup() {
  size(1000,1000);
  background(#FFEB52);
  noCursor();
} 

void draw() {
    background(#FFEB52);
    drawCreature(mouseX,mouseY);
    fill(#311900);
    quad(0,450,300,100,350,150,0,500);
    fill(#1233FF);
    rect(0,900,1500,400);
}

void drawCreature(int x, int y) {
      strokeWeight(4);
      stroke(50);
      fill(#45D2DE);
      ellipse(x,y,400,50);
      fill(#FFFFFF);
      ellipse(x+150,y-5,10,10); // Right Eye
      ellipse(x+150,y-15,10,10);
      fill(#3A71E5);
      triangle(x+10,y+25,x-25,y+25,x-35,y+65);
      line(x+180,y-10,350,150);
      triangle(x-185,y,x-225,y-50,x-225,y+50); // Back fin
      line(x+120,y-10,x+120,y+10);
      line(x+130,y-10,x+130,y+10);
      line(x+140,y-10,x+140,y+10);
      line(x+195,y+5,x+160,y+5);
      triangle(x+10,y-25,x-25,y-25,x-35,y-65);
}
