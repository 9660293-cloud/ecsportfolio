// Ole Leimbach | Mar 31 2026 | ShapeGame
PImage bannana;
int score = 0;
int imgX, imgY;
int imgW, imgH;

void setup() {
  size(1000, 600);
  bannana = loadImage("bannana.png");
  imgW = bannana.width;
  imgH = bannana.height;
  moveImageRandomly();
}

void draw() {
  background(#1CCB10);
  image(bannana, imgX, imgY);
  fill(#F51616,100);
  rect(0,0,1000,60);
  fill(0);
  textSize(40);
  text("Score: " + score, 20, 40);
}

void mousePressed() {

  if (mouseX > imgX && mouseX < imgX + imgW &&
    mouseY > imgY && mouseY < imgY + imgH) {

    score++;
    moveImageRandomly();
  }
}

void moveImageRandomly() {
  imgX = (int) random(0, width - 200);
  imgY = (int) random(0, height - 200);
}
