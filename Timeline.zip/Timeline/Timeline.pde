// Ole Leimbach | 26 Feb | Timeline
void setup() {
  size(950,400);
}
void draw() {
  background(#4093EA);
  drawRef();
  histEvent(150,200,"First March Maddness Berth",true, "1939: This was the first year that the Utah State Basketball team was successful enough to recieve a spot in the \n major men's college basketball tournment"); //First Event
  histEvent(170,300,"Death of Wayne Estes",false,"1965: This was the tragic death of an amazing Utah State Basketball player whne he was only a sophmore,\n he is still a unifying symbol for the Utah State basketball communnity today");  //Second Event
  histEvent(360,200,"Elite Eight",true, "1970: Under coach LaDell Andersen, the Aggies reached the Elite Eight of the NCAA Tournament, matching the furthest advancement in school history \n an achomplishment that will forever remain in Utah State History"); //First Event
  histEvent(380,300,"New Stadium",false, "1970: This was the year that the Utah State Basketball team had the new, high-tech Spectrum staduim constructed for them \n and it is the same stadium that the team play in today"); //First Event
  histEvent(575,200,"NCAA Upset of Ohio State",true, "2001: This was when Utah State Basketball upset a highly favored Ohio State team in the NCAA Tournament \n this will be a moment that will forever remain in the memories of fan and Utah State Basketball"); //First Event
  histEvent(590,300,"30-Win Season",false, "2009: This was the year that Utah State Basketball was amazingly sucessful, winning 30 games which is an impressive feat for \n even the best teams considearing that team play at most 32 games and it will be a season that will forever be remembered by the Utah State community"); //First Event
  histEvent(780,200,"Mountain West Championship",true, "2019: This was when the Utah State Basketball team won their conference championship on an amazing shot from Sam Merril \n this was a moment when Utah state started to be recognized as a powerhouse program in the west"); //First Event
  histEvent(800,300,"First Tournament Year in 24 yrs",false, "2024: This was the first year in 23 years that the Utah State Basketball team won a game in the major college basketball \n tournament, the NCAA Tournament, which was quite a relief to the fans and the team"); //First Event
}
void drawRef() {
  textAlign(CENTER);
  textSize(38);
  text("Utah State Basketball: Timeline",width/2,65);
  textSize(19);
  text("by Ole Leimbach",width/2,90);
  strokeWeight(4);
  line(50,250,900,250);
  line(50,245,50,255);
  line(900,245,900,255);
  line(200,245,200,255);
  line(500,245,500,255);
  line(670,245,670,255);
  line(350,245,350,255);
  line(800,245,800,255);
  strokeWeight(2);
  textSize(15);
  text("1930",50,275);  // First Decade
  text("2040",900,275); //Last Decade 
}
void histEvent(int x, int y, String title, boolean top, String detail) {
  if(top == true) {
    line(x,y,x-15,y+50);
  } else {
  line(x,y,x-15,y-50);
  }
  rectMode(CENTER);
  fill(#06294D);
  rect(x,y,200,30,12);   
  fill(#FFFFFF);
  text(title,x,y+5);
  if(mouseX > x-100 && mouseX< x+100 && mouseY > y-15 && mouseY < y+15) {
    text(detail,width/2,350);
  }
}
