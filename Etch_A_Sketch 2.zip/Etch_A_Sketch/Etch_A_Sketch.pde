// Ole Leimbach || 17 Mar || Etch-A-Sketch
int x, y;
PImage e1;

void setup() {
  size(1001, 818);      
  background(255);    
  strokeWeight(3);   
  stroke(50);          
  e1 = loadImage("Etch.png");
 
  x = width / 2;
  y = height / 2;
}

void draw() {
  image(e1,0,0);
  
}

void keyPressed() {
  int step = 3;
  
  if (key == CODED) {
    if (keyCode == UP) {
      moveUp(step);
    } else if (keyCode == DOWN) {
      moveDown(step);
    } else if (keyCode == LEFT) {
      moveLeft(step);
    } else if (keyCode == RIGHT) {
      moveRight(step);
    }
  } else {
    
    if (key == '9') {
      background(200); 
      x = width / 2;
      y = height / 2;
    }
  }
}

void moveRight(int l) {
  line(x, y, x+l, y);
  x += l;
}

void moveLeft(int l) {
  line(x, y, x-l, y);
  x -= l;
}

void moveUp(int l) {
  line(x, y, x, y-l);
  y -= l;
}

void moveDown(int l) {
  line(x, y, x, y+l);
  y += l;
}

void mouseReleased() {
  saveFrame("line-######.png");
}
