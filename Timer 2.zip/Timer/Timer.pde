// Ole Leimbach | 26 Mar | Timer
import processing.sound.*;
SoundFile alarm;
Button btnStart, btnStop, btnReset;
int totalTime = 10;
int startTime = 0;
int timeLeft = 0;
boolean running = false;

void setup() {
  size(500, 500);
  alarm = new SoundFile(this, "alarm.mp3");
  btnStart = new Button(250, 350, 100, 30, "Start", color(#F7170F), color(60));
  btnStop = new Button(400, 350, 100, 30, "Stop", color(#0A2CFF), color(60));
  btnReset = new Button(100, 350, 100, 30, "Reset", color(#1CE82B), color(60));
  timeLeft = totalTime;
}

void draw() {
  background(127);

  if (running == true) {
    int elapsed = (millis() - startTime)/1000;
    timeLeft = totalTime - elapsed;

    if (timeLeft <= 0) {
      timeLeft = 0;
      running = false;
      // play sound
      alarm.play();
    }
  }

  btnStart.display();
  btnStart.hover();
  btnStop.display();
  btnStop.hover();
  btnReset.display();
  btnReset.hover();

  fill(#082898);
  rect(width/2, 220, width-100, 150, 70);
  textSize(100);
  fill(#000000);
  text(timeLeft, width/2, 200);
  alarm.play();

  textSize(12);
  text("by Ole Steed Leimbach", width/2, 480);
}

void mousePressed() {
  if (btnStart.over == true) {
    running = true;
    startTime = millis();
  }

  if (btnReset.over == true) {
    timeLeft = 10;
    running = true;
    startTime = millis();
  }

  if (btnStop.over == true) {
    running = false;
  }
}
