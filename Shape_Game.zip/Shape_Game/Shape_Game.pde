// Ole Leimbach | 3 Mar | ShapeGame
int x, y, tx, ty, score;
Float tw;
PImage player;
PImage target;

void setup() {
  size(800, 800);
  x = width/2;
  y = height/2;
  tx = int(random(20, width-20));
  ty = int(random(20, height-20));
  score = 0;
  tw = 100.0;
  player = loadImage("Dude.png");
  target = loadImage("Banana.png");
}

void draw() {
  background(127);
  //ellipse(x, y, 20, 20);
  imageMode(CENTER);
  image(player, x, y);
  player.resize(75, 75);
  target();
  scorePanel();
}

void scorePanel() {
  fill(#236BF7, 127);
  rect(width/2, 15, width, 30);
  fill(255);
  textSize(32);
  text("Score:" + score, 20, 25);
}

void target() {
  float d = dist(x, y, tx, ty);
  rectMode(CENTER);
  imageMode(CENTER);
  image(target, tx, ty, tw, tw);
  target.resize(75, 75);
  println(d);
  if (d<tw) {
    score = score + int(tw);
    tx = int(random(20, width-20));
    ty = int(random(20, height-20));
    tw = 100.0;
  }
  tw = tw - 0.3;
  if (tw <= 10) {
    gameOver();
  }
}

void gameOver() {
  background(0);
  fill(255);
  textAlign(CENTER);
  text("Game Over", width/2, height/2);
}

void keyPressed() {
  if (y<0) {
    y = height;
  }
  if (y>height) {
    y = 0;
  }
  if (x<0) {
    x = height;
  }
  if (x>height) {
    x = 0;
  }


  if (key == 'w' || key == 'W') {
    y = y - 15;
  } else if (key == 's' || key == 'S') {
    y = y + 15;
  } else if (key == 'a' || key == 'A') {
    x = x - 15;
  } else if (key == 'd' || key == 'D') {
    x = x + 15;
  }
}
